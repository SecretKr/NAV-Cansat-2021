﻿Imports System.IO.Ports

Public Class Nav

    Dim lat As String
    Dim lon As String
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.CenterToParent()
        Me.Text = "Nav"
        btConnect.Enabled = False
        btConnect.BringToFront()
        'Dim t
        't = SystemColors.Window

        btDisconnect.Enabled = False
        btDisconnect.SendToBack()

        cbBaud.SelectedItem = "9600"

        ChartAcc.Series("X axis").IsValueShownAsLabel = False
        ChartAcc.ChartAreas("ChartArea1").AxisX.Enabled = DataVisualization.Charting.AxisEnabled.False
        ChartAlt.Series("Alt(Pressure)").IsValueShownAsLabel = False
        ChartAlt.ChartAreas("ChartArea1").AxisX.Enabled = DataVisualization.Charting.AxisEnabled.False
        ChartAcc.ChartAreas(0).BackColor = Color.Gray
        ChartAcc.Legends(0).BackColor = Color.Gray
        ChartAlt.ChartAreas(0).BackColor = Color.Gray
        ChartAlt.Legends(0).BackColor = Color.Gray
    End Sub
    Private Sub btScan_Click(sender As Object, e As EventArgs) Handles btScan.Click
        cbScanPort.Items.Clear()
        Dim myPort As Array
        Dim i As Integer
        myPort = IO.Ports.SerialPort.GetPortNames()
        cbScanPort.Items.AddRange(myPort)
        i = cbScanPort.Items.Count
        i = i - i
        Try
            cbScanPort.SelectedIndex = i
        Catch ex As Exception
            Dim result As DialogResult
            result = MessageBox.Show("com port not detected", "Warning!!!", MessageBoxButtons.OK)
            cbScanPort.Text = ""
            cbScanPort.Items.Clear()
        End Try
        btConnect.Enabled = True
        btConnect.BringToFront()
    End Sub

    Private Sub btConnect_Click(sender As Object, e As EventArgs) Handles btConnect.Click
        btConnect.Enabled = False
        btConnect.SendToBack()

        SerialPort1.BaudRate = cbBaud.SelectedItem
        SerialPort1.PortName = cbScanPort.SelectedItem
        SerialPort1.Open()
        Timer1.Start()

        btDisconnect.Enabled = True
        btDisconnect.BringToFront()

        SerialPort1.ReadTimeout = 20
    End Sub

    Private Sub btDisconnect_Click(sender As Object, e As EventArgs) Handles btDisconnect.Click
        btDisconnect.Enabled = False
        btDisconnect.SendToBack()

        Timer1.Stop()
        SerialPort1.Close()

        btConnect.Enabled = True
        btConnect.BringToFront()
    End Sub

    Private Sub cbScanPort_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbScanPort.SelectedIndexChanged

    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Try
            Dim r As String = SerialPort1.ReadLine()
            Console.WriteLine(r)
            Dim rs() As String = r.Split(",")

            If String.Compare(rs(0), "img") <> 0 Then
                val.Text = r
                ChartAcc.Series("X axis").Points.AddY(rs(3))
                ChartAcc.Series("Y axis").Points.AddY(rs(4))
                ChartAcc.Series("Z axis").Points.AddY(rs(5))
                ChartAlt.Series("Alt(Pressure)").Points.AddY(rs(8))
                ChartAlt.Series("Alt(Ultrasonic)").Points.AddY(rs(9))
                temp.Text = rs(7) & "°C"
                battery.Text = rs(11) & "%"
                heading.Text = rs(6) & "°"
                If String.Compare(rs(10), "0") = 0 Then
                    sensor.Text = "Safe"
                End If
                If String.Compare(rs(10), "1") = 0 Then
                    sensor.Text = "Broken"
                End If
                Servol.Text = "Servo-L" & rs(12)
                servor.Text = "Servo-R" & rs(13)
                lat = rs(1)
                lon = rs(2)
                miku.Text = rs(1)
                nino.Text = rs(2)
                AltText.Text = rs(8) & " m"
                If String.Compare(rs(14), "0") = 0 Then
                    status.Text = "Stand by"
                End If
                If String.Compare(rs(14), "1") = 0 Then
                    status.Text = "Launched"
                End If
                If String.Compare(rs(14), "2") = 0 Then
                    status.Text = "SOS"
                End If
                If ChartAcc.Series(0).Points.Count = 10 Then
                    ChartAcc.Series(0).Points.RemoveAt(0)
                    ChartAcc.Series(1).Points.RemoveAt(0)
                    ChartAcc.Series(2).Points.RemoveAt(0)
                    ChartAlt.Series(0).Points.RemoveAt(0)
                    ChartAlt.Series(1).Points.RemoveAt(0)
                End If
                ChartAcc.ChartAreas(0).AxisY.Maximum = 2
                ChartAcc.ChartAreas(0).AxisY.Minimum = -2
                ChartAlt.ChartAreas(0).AxisY.Maximum = 20
                ChartAlt.ChartAreas(0).AxisY.Minimum = 0
            End If
            If String.Compare(rs(0), "img") = 0 Then
                Dim bytes() As Byte
                bytes = System.Convert.FromBase64String(rs(1))
                Dim writer As New System.IO.BinaryWriter(IO.File.Open("tmp.jpg", IO.FileMode.Create))
                writer.Write(bytes)
                writer.Close()

                Using OriginalImage = Image.FromFile("tmp.jpg")
                    Using ResizedImage As New Bitmap(OriginalImage, 800, 500)
                        ResizedImage.Save("tmp2.jpg", Drawing.Imaging.ImageFormat.Jpeg)
                    End Using
                End Using

                Dim filename As String = System.IO.Path.Combine("tmp2.jpg")
                Try
                    Using fs As New System.IO.FileStream(filename, IO.FileMode.Open)
                        frame.Image = New Bitmap(Image.FromStream(fs))
                    End Using
                Catch ex As Exception
                    Dim msg As String = "Filename: " & filename &
                        Environment.NewLine & Environment.NewLine &
                        "Exception: " & ex.ToString
                    MessageBox.Show(msg, "Error Opening Image File")
                End Try
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub showMap_Click(sender As Object, e As EventArgs) Handles showMap.Click
        'Web.Url = New Uri("http://maps.google.com/maps?output=embed&z=9&ll=" & lat & "," & lon)
        Process.Start("http://www.google.com/maps/search/?api=1&query=" & lat & "," & lon)
    End Sub

    Private Sub sensor_Click(sender As Object, e As EventArgs) Handles sensor.Click

    End Sub

End Class
