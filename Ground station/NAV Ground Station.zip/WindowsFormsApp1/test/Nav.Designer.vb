﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Nav
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim ChartArea1 As System.Windows.Forms.DataVisualization.Charting.ChartArea = New System.Windows.Forms.DataVisualization.Charting.ChartArea()
        Dim Legend1 As System.Windows.Forms.DataVisualization.Charting.Legend = New System.Windows.Forms.DataVisualization.Charting.Legend()
        Dim Series1 As System.Windows.Forms.DataVisualization.Charting.Series = New System.Windows.Forms.DataVisualization.Charting.Series()
        Dim Series2 As System.Windows.Forms.DataVisualization.Charting.Series = New System.Windows.Forms.DataVisualization.Charting.Series()
        Dim Series3 As System.Windows.Forms.DataVisualization.Charting.Series = New System.Windows.Forms.DataVisualization.Charting.Series()
        Dim ChartArea2 As System.Windows.Forms.DataVisualization.Charting.ChartArea = New System.Windows.Forms.DataVisualization.Charting.ChartArea()
        Dim Legend2 As System.Windows.Forms.DataVisualization.Charting.Legend = New System.Windows.Forms.DataVisualization.Charting.Legend()
        Dim Series4 As System.Windows.Forms.DataVisualization.Charting.Series = New System.Windows.Forms.DataVisualization.Charting.Series()
        Dim Series5 As System.Windows.Forms.DataVisualization.Charting.Series = New System.Windows.Forms.DataVisualization.Charting.Series()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Nav))
        Me.btDisconnect = New System.Windows.Forms.Button()
        Me.btConnect = New System.Windows.Forms.Button()
        Me.cbBaud = New System.Windows.Forms.ComboBox()
        Me.cbScanPort = New System.Windows.Forms.ComboBox()
        Me.btScan = New System.Windows.Forms.Button()
        Me.label1 = New System.Windows.Forms.Label()
        Me.val = New System.Windows.Forms.Label()
        Me.SerialPort1 = New System.IO.Ports.SerialPort(Me.components)
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.ChartAcc = New System.Windows.Forms.DataVisualization.Charting.Chart()
        Me.ChartAlt = New System.Windows.Forms.DataVisualization.Charting.Chart()
        Me.temp = New System.Windows.Forms.Label()
        Me.battery = New System.Windows.Forms.Label()
        Me.sensor = New System.Windows.Forms.Label()
        Me.heading = New System.Windows.Forms.Label()
        Me.frame = New System.Windows.Forms.PictureBox()
        Me.showMap = New System.Windows.Forms.Button()
        Me.Servol = New System.Windows.Forms.Label()
        Me.status = New System.Windows.Forms.Label()
        Me.miku = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.servor = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.nino = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.AltText = New System.Windows.Forms.Label()
        CType(Me.ChartAcc, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ChartAlt, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.frame, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btDisconnect
        '
        Me.btDisconnect.Enabled = False
        Me.btDisconnect.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btDisconnect.Location = New System.Drawing.Point(432, 70)
        Me.btDisconnect.Name = "btDisconnect"
        Me.btDisconnect.Size = New System.Drawing.Size(140, 34)
        Me.btDisconnect.TabIndex = 11
        Me.btDisconnect.Text = "Disconnect"
        Me.btDisconnect.UseVisualStyleBackColor = True
        '
        'btConnect
        '
        Me.btConnect.Enabled = False
        Me.btConnect.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btConnect.Location = New System.Drawing.Point(432, 20)
        Me.btConnect.Name = "btConnect"
        Me.btConnect.Size = New System.Drawing.Size(140, 34)
        Me.btConnect.TabIndex = 10
        Me.btConnect.Text = "Connect"
        Me.btConnect.UseVisualStyleBackColor = True
        '
        'cbBaud
        '
        Me.cbBaud.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbBaud.FormattingEnabled = True
        Me.cbBaud.Items.AddRange(New Object() {"1200", "2400", "4800", "9600", "19200", "38400", "57600", "115200"})
        Me.cbBaud.Location = New System.Drawing.Point(272, 70)
        Me.cbBaud.Name = "cbBaud"
        Me.cbBaud.Size = New System.Drawing.Size(146, 33)
        Me.cbBaud.TabIndex = 9
        '
        'cbScanPort
        '
        Me.cbScanPort.BackColor = System.Drawing.Color.White
        Me.cbScanPort.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbScanPort.FormattingEnabled = True
        Me.cbScanPort.IntegralHeight = False
        Me.cbScanPort.Location = New System.Drawing.Point(272, 20)
        Me.cbScanPort.Name = "cbScanPort"
        Me.cbScanPort.Size = New System.Drawing.Size(146, 33)
        Me.cbScanPort.TabIndex = 8
        '
        'btScan
        '
        Me.btScan.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btScan.Location = New System.Drawing.Point(145, 21)
        Me.btScan.Name = "btScan"
        Me.btScan.Size = New System.Drawing.Size(116, 33)
        Me.btScan.TabIndex = 7
        Me.btScan.Text = "Scan"
        Me.btScan.UseVisualStyleBackColor = True
        '
        'label1
        '
        Me.label1.BackColor = System.Drawing.Color.Transparent
        Me.label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label1.ForeColor = System.Drawing.Color.Black
        Me.label1.Location = New System.Drawing.Point(140, 71)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(121, 33)
        Me.label1.TabIndex = 6
        Me.label1.Text = "Baud Rate:"
        Me.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'val
        '
        Me.val.BackColor = System.Drawing.Color.Transparent
        Me.val.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.val.ForeColor = System.Drawing.Color.Silver
        Me.val.Location = New System.Drawing.Point(15, 647)
        Me.val.Name = "val"
        Me.val.Size = New System.Drawing.Size(1120, 26)
        Me.val.TabIndex = 12
        Me.val.Text = "Data"
        Me.val.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'SerialPort1
        '
        Me.SerialPort1.PortName = "COM6"
        '
        'Timer1
        '
        '
        'ChartAcc
        '
        Me.ChartAcc.BackColor = System.Drawing.Color.Gray
        Me.ChartAcc.BorderSkin.BorderColor = System.Drawing.Color.Gray
        Me.ChartAcc.BorderSkin.PageColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        ChartArea1.Name = "ChartArea1"
        Me.ChartAcc.ChartAreas.Add(ChartArea1)
        Legend1.Name = "Legend1"
        Me.ChartAcc.Legends.Add(Legend1)
        Me.ChartAcc.Location = New System.Drawing.Point(12, 119)
        Me.ChartAcc.Name = "ChartAcc"
        Series1.BackImageTransparentColor = System.Drawing.Color.Gray
        Series1.BackSecondaryColor = System.Drawing.Color.Gray
        Series1.BorderColor = System.Drawing.Color.Gray
        Series1.BorderWidth = 3
        Series1.ChartArea = "ChartArea1"
        Series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line
        Series1.Color = System.Drawing.Color.Red
        Series1.LabelBackColor = System.Drawing.Color.Gray
        Series1.LabelBorderColor = System.Drawing.Color.Gray
        Series1.Legend = "Legend1"
        Series1.MarkerBorderColor = System.Drawing.Color.Gray
        Series1.MarkerColor = System.Drawing.Color.Gray
        Series1.Name = "X axis"
        Series1.YValuesPerPoint = 2
        Series2.BorderWidth = 3
        Series2.ChartArea = "ChartArea1"
        Series2.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line
        Series2.Color = System.Drawing.Color.Lime
        Series2.Legend = "Legend1"
        Series2.Name = "Y axis"
        Series3.BorderWidth = 3
        Series3.ChartArea = "ChartArea1"
        Series3.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line
        Series3.Color = System.Drawing.Color.Blue
        Series3.Legend = "Legend1"
        Series3.Name = "Z axis"
        Me.ChartAcc.Series.Add(Series1)
        Me.ChartAcc.Series.Add(Series2)
        Me.ChartAcc.Series.Add(Series3)
        Me.ChartAcc.Size = New System.Drawing.Size(560, 187)
        Me.ChartAcc.TabIndex = 13
        Me.ChartAcc.Text = "ChartAcc"
        '
        'ChartAlt
        '
        Me.ChartAlt.BackColor = System.Drawing.Color.Gray
        ChartArea2.Name = "ChartArea1"
        Me.ChartAlt.ChartAreas.Add(ChartArea2)
        Legend2.Name = "Legend1"
        Me.ChartAlt.Legends.Add(Legend2)
        Me.ChartAlt.Location = New System.Drawing.Point(12, 302)
        Me.ChartAlt.Name = "ChartAlt"
        Series4.BorderWidth = 3
        Series4.ChartArea = "ChartArea1"
        Series4.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line
        Series4.Color = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Series4.LabelForeColor = System.Drawing.Color.White
        Series4.Legend = "Legend1"
        Series4.Name = "Alt(Pressure)"
        Series5.BorderWidth = 3
        Series5.ChartArea = "ChartArea1"
        Series5.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line
        Series5.Color = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Series5.Legend = "Legend1"
        Series5.Name = "Alt(Ultrasonic)"
        Me.ChartAlt.Series.Add(Series4)
        Me.ChartAlt.Series.Add(Series5)
        Me.ChartAlt.Size = New System.Drawing.Size(560, 196)
        Me.ChartAlt.TabIndex = 14
        Me.ChartAlt.Text = "ChartAlt"
        '
        'temp
        '
        Me.temp.BackColor = System.Drawing.Color.Transparent
        Me.temp.Font = New System.Drawing.Font("Microsoft Sans Serif", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.temp.ForeColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.temp.Location = New System.Drawing.Point(464, 567)
        Me.temp.Name = "temp"
        Me.temp.Size = New System.Drawing.Size(218, 69)
        Me.temp.TabIndex = 15
        Me.temp.Text = "N/A"
        Me.temp.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'battery
        '
        Me.battery.BackColor = System.Drawing.Color.Transparent
        Me.battery.Font = New System.Drawing.Font("Microsoft Sans Serif", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.battery.ForeColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.battery.Location = New System.Drawing.Point(12, 567)
        Me.battery.Name = "battery"
        Me.battery.Size = New System.Drawing.Size(217, 69)
        Me.battery.TabIndex = 16
        Me.battery.Text = "N/A"
        Me.battery.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'sensor
        '
        Me.sensor.BackColor = System.Drawing.Color.Transparent
        Me.sensor.Font = New System.Drawing.Font("Microsoft Sans Serif", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.sensor.ForeColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.sensor.Location = New System.Drawing.Point(924, 567)
        Me.sensor.Name = "sensor"
        Me.sensor.Size = New System.Drawing.Size(211, 69)
        Me.sensor.TabIndex = 17
        Me.sensor.Text = "N/A"
        Me.sensor.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'heading
        '
        Me.heading.BackColor = System.Drawing.Color.Transparent
        Me.heading.Font = New System.Drawing.Font("Microsoft Sans Serif", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.heading.ForeColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.heading.Location = New System.Drawing.Point(694, 567)
        Me.heading.Name = "heading"
        Me.heading.Size = New System.Drawing.Size(224, 69)
        Me.heading.TabIndex = 18
        Me.heading.Text = "N/A"
        Me.heading.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'frame
        '
        Me.frame.BackColor = System.Drawing.Color.Gray
        Me.frame.Location = New System.Drawing.Point(578, 183)
        Me.frame.Name = "frame"
        Me.frame.Size = New System.Drawing.Size(560, 315)
        Me.frame.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.frame.TabIndex = 19
        Me.frame.TabStop = False
        '
        'showMap
        '
        Me.showMap.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.showMap.Location = New System.Drawing.Point(961, 19)
        Me.showMap.Name = "showMap"
        Me.showMap.Size = New System.Drawing.Size(177, 83)
        Me.showMap.TabIndex = 21
        Me.showMap.Text = "Map"
        Me.showMap.UseVisualStyleBackColor = True
        '
        'Servol
        '
        Me.Servol.BackColor = System.Drawing.Color.Gray
        Me.Servol.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Servol.ForeColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Servol.Location = New System.Drawing.Point(578, 119)
        Me.Servol.Name = "Servol"
        Me.Servol.Size = New System.Drawing.Size(274, 61)
        Me.Servol.TabIndex = 22
        Me.Servol.Text = "Servo-L  N/A"
        Me.Servol.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'status
        '
        Me.status.BackColor = System.Drawing.Color.Transparent
        Me.status.Font = New System.Drawing.Font("Microsoft Sans Serif", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.status.ForeColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.status.Location = New System.Drawing.Point(241, 567)
        Me.status.Name = "status"
        Me.status.Size = New System.Drawing.Size(218, 69)
        Me.status.TabIndex = 23
        Me.status.Text = "Disconnect"
        Me.status.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'miku
        '
        Me.miku.BackColor = System.Drawing.Color.Transparent
        Me.miku.Font = New System.Drawing.Font("Microsoft Sans Serif", 26.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.miku.ForeColor = System.Drawing.Color.Black
        Me.miku.Location = New System.Drawing.Point(766, 14)
        Me.miku.Name = "miku"
        Me.miku.Size = New System.Drawing.Size(189, 42)
        Me.miku.TabIndex = 24
        Me.miku.Text = "N/A"
        Me.miku.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.InitialImage = CType(resources.GetObject("PictureBox1.InitialImage"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(12, 8)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(116, 105)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 25
        Me.PictureBox1.TabStop = False
        '
        'servor
        '
        Me.servor.BackColor = System.Drawing.Color.Gray
        Me.servor.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.servor.ForeColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.servor.Location = New System.Drawing.Point(858, 119)
        Me.servor.Name = "servor"
        Me.servor.Size = New System.Drawing.Size(280, 61)
        Me.servor.TabIndex = 26
        Me.servor.Text = "Servo-R  N/A"
        Me.servor.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Label2.Location = New System.Drawing.Point(12, 501)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(217, 66)
        Me.Label2.TabIndex = 27
        Me.Label2.Text = "Battery"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Label3.Location = New System.Drawing.Point(242, 501)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(217, 66)
        Me.Label3.TabIndex = 28
        Me.Label3.Text = "Status"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label4
        '
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Label4.Location = New System.Drawing.Point(472, 501)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(217, 66)
        Me.Label4.TabIndex = 29
        Me.Label4.Text = "Temperature"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label5
        '
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Label5.Location = New System.Drawing.Point(695, 501)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(217, 66)
        Me.Label5.TabIndex = 30
        Me.Label5.Text = "Heading"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label6
        '
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Label6.Location = New System.Drawing.Point(918, 501)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(217, 66)
        Me.Label6.TabIndex = 31
        Me.Label6.Text = "Pencil Lead"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'nino
        '
        Me.nino.BackColor = System.Drawing.Color.Transparent
        Me.nino.Font = New System.Drawing.Font("Microsoft Sans Serif", 26.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.nino.ForeColor = System.Drawing.Color.Black
        Me.nino.Location = New System.Drawing.Point(766, 64)
        Me.nino.Name = "nino"
        Me.nino.Size = New System.Drawing.Size(189, 42)
        Me.nino.TabIndex = 32
        Me.nino.Text = "N/A"
        Me.nino.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label7
        '
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 26.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.Black
        Me.Label7.Location = New System.Drawing.Point(587, 14)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(189, 42)
        Me.Label7.TabIndex = 33
        Me.Label7.Text = "latitude"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label8
        '
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 26.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.Black
        Me.Label8.Location = New System.Drawing.Point(587, 63)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(189, 42)
        Me.Label8.TabIndex = 34
        Me.Label8.Text = "longitude"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'AltText
        '
        Me.AltText.BackColor = System.Drawing.Color.Gray
        Me.AltText.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AltText.ForeColor = System.Drawing.Color.Black
        Me.AltText.Location = New System.Drawing.Point(438, 360)
        Me.AltText.Name = "AltText"
        Me.AltText.Size = New System.Drawing.Size(118, 46)
        Me.AltText.TabIndex = 35
        Me.AltText.Text = "0 m"
        Me.AltText.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Nav
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Blue
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(1147, 675)
        Me.Controls.Add(Me.AltText)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.nino)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.servor)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.miku)
        Me.Controls.Add(Me.status)
        Me.Controls.Add(Me.Servol)
        Me.Controls.Add(Me.showMap)
        Me.Controls.Add(Me.frame)
        Me.Controls.Add(Me.heading)
        Me.Controls.Add(Me.sensor)
        Me.Controls.Add(Me.battery)
        Me.Controls.Add(Me.temp)
        Me.Controls.Add(Me.ChartAlt)
        Me.Controls.Add(Me.ChartAcc)
        Me.Controls.Add(Me.val)
        Me.Controls.Add(Me.btDisconnect)
        Me.Controls.Add(Me.btConnect)
        Me.Controls.Add(Me.cbBaud)
        Me.Controls.Add(Me.cbScanPort)
        Me.Controls.Add(Me.btScan)
        Me.Controls.Add(Me.label1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Nav"
        Me.Text = "Form1"
        CType(Me.ChartAcc, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ChartAlt, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.frame, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Private WithEvents btDisconnect As Button
    Private WithEvents btConnect As Button
    Private WithEvents cbBaud As ComboBox
    Private WithEvents cbScanPort As ComboBox
    Private WithEvents btScan As Button
    Private WithEvents label1 As Label
    Friend WithEvents val As Label
    Friend WithEvents SerialPort1 As IO.Ports.SerialPort
    Friend WithEvents Timer1 As Timer
    Friend WithEvents ChartAcc As DataVisualization.Charting.Chart
    Friend WithEvents ChartAlt As DataVisualization.Charting.Chart
    Friend WithEvents temp As Label
    Friend WithEvents battery As Label
    Friend WithEvents sensor As Label
    Friend WithEvents heading As Label
    Friend WithEvents frame As PictureBox
    Friend WithEvents showMap As Button
    Friend WithEvents Servol As Label
    Friend WithEvents status As Label
    Friend WithEvents miku As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents servor As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents nino As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents AltText As Label
End Class
